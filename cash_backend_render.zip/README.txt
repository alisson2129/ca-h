Backend CA$H - Pronto para deploy na Render ou Railway

1. Suba os arquivos para um repositório no GitHub.
2. Acesse render.com (ou railway.app), conecte seu GitHub e crie um novo Web Service.
3. Configure assim:
   - Build Command: pip install -r requirements.txt
   - Start Command: python app.py
   - Environment: Python 3.x
4. Aguarde o deploy e acesse a URL gerada.