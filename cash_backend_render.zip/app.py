from flask import Flask, request, jsonify
from flask_cors import CORS
import pdfplumber

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return "Backend do CA$H está no ar!"

@app.route('/analisar', methods=['POST'])
def analisar_extrato():
    if 'file' not in request.files:
        return jsonify({'erro': 'Nenhum arquivo enviado'}), 400

    arquivo = request.files['file']
    if arquivo.filename == '':
        return jsonify({'erro': 'Arquivo vazio'}), 400

    try:
        texto_extraido = ""
        with pdfplumber.open(arquivo.stream) as pdf:
            for pagina in pdf.pages:
                texto_extraido += pagina.extract_text() + "\n"

        categorias = {
            'alimentação': ['mercado', 'supermercado', 'padaria', 'hortifruti'],
            'restaurante': ['restaurante', 'lanchonete', 'mc donalds'],
            'farmácia': ['farmácia', 'drogasil', 'droga', 'medicamento'],
            'investimento': ['tesouro', 'cdb', 'ação', 'btc', 'cripto'],
            'salário': ['salário', 'empresa', 'pagamento'],
        }

        resultado = []
        linhas = texto_extraido.split('\n')
        for linha in linhas:
            linha_lower = linha.lower()
            categoria = 'Outros'
            for cat, palavras in categorias.items():
                if any(p in linha_lower for p in palavras):
                    categoria = cat
                    break
            resultado.append({
                'linha': linha,
                'categoria': categoria
            })

        return jsonify({'transacoes': resultado})

    except Exception as e:
        return jsonify({'erro': str(e)}), 500

if __name__ == '__main__':
    app.run()